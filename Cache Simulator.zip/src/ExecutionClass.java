import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;


public class ExecutionClass {

	private CacheArchitecture cache;
	private Map<String, String> hexToBitTable;
	private List<String> originalHexData;
	//declaring map and list for conversion
	
	int l1_Cache_Reads, l1_Cache_Read_Misses, l1_Cache_Writes, l1_Cache_Write_Misses, l1_Cache_Writebacks, l2_Cache_Reads, l2_Cache_Read_Misses, l2_Cache_Writes, l2_Cache_Write_Misses, l2_Cache_Writebacks, memTraffic;
	int inclusionEvictionCount , globalOPTIndex = 0;
	
	public ExecutionClass(CacheArchitecture cache, Map<String, String> map, List<String> data) {
		this.cache = cache;
		this.hexToBitTable = map;
		this.originalHexData = data;
		iterateThroughData();
	}
	
	private double compute_L2_Cache_MissRate() {
		
		return (double)(l2_Cache_Read_Misses)/(double)(l1_Cache_Read_Misses + l1_Cache_Write_Misses);
	}


	private double compute_L1_Cache_MissRate() {
		
		return (double)(l1_Cache_Read_Misses + l1_Cache_Write_Misses)/(double)(l1_Cache_Reads + l1_Cache_Writes);
	}


	private String binaryToHexaDecimal(String str)
	{
		return new BigInteger(str,2).toString(16);
	}
	
	void computeHexToIndexMapping() {
		for(int i=0; i<originalHexData.size(); i++)
		{
			String str = originalHexData.get(i);
			
			String temp = str.split(" ")[1];
			
			int index = getL1Index(hexToBitTable.get(temp));
			
			if(!hexDataToIndexMap.containsKey(index))
				hexDataToIndexMap.put(index, new ArrayList<>());
			hexDataToIndexMap.get(index).add(new BlockforOptimalPolicy(temp,i));
		}
		
	}
	
	int getL1Index(String str)
	{
		try {
		return Integer.parseInt(str.substring(cache.l1_TagBits,cache.l1_TagBits+cache.l1_IndexBits),2);
		}catch(Exception e) {
			return 0;
		}
	}
	
	int getL2Index(String str)
	{
		try {
		return Integer.parseInt(str.substring(cache.l2_TagBits,cache.l2_TagBits+cache.l2_IndexBits),2);
		}catch(Exception e) {
			return 0;
		}
	}
	
	String getL1CacheTagBits(String str)
	{
		return str.substring(0,cache.l1_TagBits);
	}
	
	String getL2CacheTagBits(String str)
	{
		return str.substring(0,cache.l2_TagBits);
	}
	
	
	
	
	Map<Integer, List<BlockforOptimalPolicy>> hexDataToIndexMap;
	
	
	private void iterateThroughData() {
		// TODO Auto-generated method stub
		
		hexDataToIndexMap = new HashMap<>();
		
		computeHexToIndexMapping();
		
		
		
		for(int i=0; i<originalHexData.size(); i++)
		{	
			String str = originalHexData.get(i);
			
			globalOPTIndex = i;
			
			boolean flag = str.split(" ")[0].equals("r");
			
			str = str.split(" ")[1];
			
			if(flag)
				compute_Read_in_L1_Cache(str, hexToBitTable.get(str));
			else
				compute_Write_in_L1_Cache(str, hexToBitTable.get(str));
			
			
			
		}
		
		

	
		
		if(cache.l2_Cache.size() == 0)
		{
			memTraffic = l1_Cache_Read_Misses + l1_Cache_Write_Misses +l1_Cache_Writebacks;
		}
		else
			memTraffic = l2_Cache_Read_Misses + l2_Cache_Write_Misses +l2_Cache_Writebacks + inclusionEvictionCount;

		
		System.out.println("===== Simulator configuration =====");
		System.out.println("BLOCKSIZE:             "	+	cache.blockSize);
		System.out.println("L1_SIZE:               "	+	cache.L1_Size);
		System.out.println("L1_ASSOC:              "	+	cache.L1_Assoc);
		System.out.println("L2_SIZE:               "	+	cache.L2_Size);
		System.out.println("L2_ASSOC:              "	+	cache.L2_Assoc);
		System.out.println("REPLACEMENT POLICY:    "	+	(cache.replacementPolicy == 0?"LRU":(cache.replacementPolicy == 1?"Pseudo-LRU":"Optimal")));
		System.out.println("INCLUSION PROPERTY:    "	+	(cache.inclusionProperty == 0?"non-inclusive":"inclusive"));
		System.out.println("trace_file:            "	+	cache.traceFileData);
		
		
		
		System.out.println("===== L1 contents =====");
		
		for(int i=0; i<cache.l1_Cache.size(); i++)
		{
			//if(cache.L1.get(i).size()!=0)
			System.out.print("Set     "+i+":");
			for(DataBlock cb:cache.l1_Cache.get(i)) {
				System.out.print(" "+binaryToHexaDecimal(cb.getTagBits())+(cb.isDirtyBit()?" D":" "));
			}
			System.out.println();
		}
		
		if(cache.l2_Cache.size() != 0)
		{
			System.out.println("===== L2 contents =====");
			
			for(int i=0; i<cache.l2_Cache.size(); i++)
			{
				//if(cache.L1.get(i).size()!=0)
				System.out.print("Set     "+i+":");
				for(DataBlock cb:cache.l2_Cache.get(i)) {
					System.out.print(" "+binaryToHexaDecimal(cb.getTagBits())+(cb.isDirtyBit()?" D":" "));
				}
				System.out.println();
			}
		}
		
		System.out.println("===== Simulation results (raw) =====");
		
		System.out.println("a. number of L1 reads:        "	+	l1_Cache_Reads);
		System.out.println("b. number of L1 read misses:  "	+	l1_Cache_Read_Misses);
		System.out.println("c. number of L1 writes:       "	+	l1_Cache_Writes);
		System.out.println("d. number of L1 write misses: "	+	l1_Cache_Write_Misses);
		System.out.println("e. L1 miss rate:              "	+	String.format("%.6f",compute_L1_Cache_MissRate()));
		System.out.println("f. number of L1 writebacks:   "	+	l1_Cache_Writebacks);
		System.out.println("g. number of L2 reads:        "	+	l2_Cache_Reads);
		System.out.println("h. number of L2 read misses:  "	+	l2_Cache_Read_Misses);
		System.out.println("i. number of L2 writes:       "	+	l2_Cache_Writes);
		System.out.println("j. number of L2 write misses: "	+	l2_Cache_Write_Misses);
		System.out.println("k. L2 miss rate:              "	+	String.format("%.6f",compute_L2_Cache_MissRate()));
		System.out.println("l. number of L2 writebacks:   "	+	l2_Cache_Writebacks);
		System.out.println("m. total memory traffic:      "	+	memTraffic);
		 
		 
		
	}

	
	

	
	
	
	
	
	
	
	int blankCounter = 0;
	List<Integer> blankIndexHolder = new ArrayList<>();
	int currentRowIndex = 0;
	
	private void compute_Read_in_L1_Cache(String originalHexData, String bitsForData) {
		// TODO Auto-generated method stub
		
		List<DataBlock> li = cache.l1_Cache.get(getL1Index(bitsForData));
		String tagBits = getL1CacheTagBits(bitsForData);
		l1_Cache_Reads++;
		for(DataBlock cb: li)
		{
			if(cb.tagBits.equals(tagBits)) {
				read_hit_at_L1_Cache(tagBits, li, cb);
				compute_PLRU(cache.pseudo_LRU_L1[getL1Index(bitsForData)], li.indexOf(cb));
				return;
			}
		}
		
		currentRowIndex = getL1Index(bitsForData);
		
		l1_Cache_Read_Misses++;
		
		if(li.size()<cache.l1_Sets )
		{
			
			for(DataBlock cb: li)
			{
				cb.set_LRU_Counter(cb.get_LRU_Counter()-1);
				cb.set_OPT_Counter(cb.get_OPT_Counter()+1);
			}
			
			
			if(blankCounter != 0)
			{
				li.add(blankIndexHolder.get(0),new DataBlock(originalHexData, tagBits, cache.l1_Sets -1 , false));
				compute_PLRU(cache.pseudo_LRU_L1[getL1Index(bitsForData)], blankIndexHolder.remove(0));
				blankCounter--;
				
			}
			else
			{
				li.add(new DataBlock(originalHexData, tagBits, cache.l1_Sets -1 , false));
				compute_PLRU(cache.pseudo_LRU_L1[getL1Index(bitsForData)], li.size()-1);
			}
			
			if(cache.l2_Cache.size() != 0)
			{
				compute_read_in_L2_Cache(originalHexData, bitsForData, false, null);
			}
		}
		else 
		{
			evictDataFrom_L1_Cache(originalHexData, tagBits, li, true);
			
		}
		
		
	}
	
	private void read_hit_at_L1_Cache(String tag, List<DataBlock> li, DataBlock c) {
			// TODO Auto-generated method stub
		
		
			int value = c.get_LRU_Counter();
			
			for(DataBlock cb: li)
			{
				if(cb.tagBits.equals(tag)) {
					
					cb.set_LRU_Counter(cache.l1_Sets-1);
					
				}
				else if(cb.get_LRU_Counter() > value)
				{
					cb.set_LRU_Counter(cb.get_LRU_Counter()-1);
				}
			}
			
			
		}
	
	
	
	private void compute_read_in_L2_Cache(String originalHexData, String bitsFromData, boolean isEvicted, DataBlock evictedBlockFromL1Cache) {
		// TODO Auto-generated method stub
		
		List<DataBlock> li = cache.l2_Cache.get(getL2Index(bitsFromData));
		String tagBits = getL2CacheTagBits(bitsFromData);
		
		if(isEvicted)
		{
			compute_write_in_L2_Cache(evictedBlockFromL1Cache.getHexData(),hexToBitTable.get(evictedBlockFromL1Cache.getHexData()));
		}
		
		l2_Cache_Reads++;
		
		for(DataBlock cb: li)
		{
			if(cb.getTagBits().equals(tagBits)) {
				read_hit_at_L2_Cache(tagBits, li, cb);
				
				
				compute_PLRU(cache.pseudo_LRU_L2[getL2Index(bitsFromData)], li.indexOf(cb));
				return;
			}
		}
		
		l2_Cache_Read_Misses++;
		currentRowIndex = getL1Index(bitsFromData);
		
		if(li.size()<cache.l2_Sets)
		{
			for(DataBlock cb: li)
			{
				cb.set_LRU_Counter(cb.get_LRU_Counter()-1);
				cb.set_OPT_Counter(cb.get_OPT_Counter()+1);
			}
				
				
			li.add(new DataBlock(originalHexData, tagBits, cache.l2_Sets -1 , false));
			
			
			compute_PLRU(cache.pseudo_LRU_L2[getL2Index(bitsFromData)], li.size()-1);
		}
		else 
		{					
			evictDataFrom_L2_cache(originalHexData, tagBits, li, true);
			
		}
		
	}


	private void read_hit_at_L2_Cache(String tag, List<DataBlock> li, DataBlock c) {
		
		int value = c.get_LRU_Counter();
		
		for(DataBlock cb: li)
		{
			if(cb.tagBits.equals(tag)) {
				
				cb.set_LRU_Counter(cache.l2_Sets-1);
				
				
				
			}
			else if(cb.get_LRU_Counter() > value)
			{
				cb.set_LRU_Counter(cb.get_LRU_Counter()-1);
			}
		}
	}


	
	
	

	
	private void compute_Write_in_L1_Cache(String originalHexData, String bitsForData) {
		// TODO Auto-generated method stub
		
		List<DataBlock> li = cache.l1_Cache.get(getL1Index(bitsForData));
		String tagBits = getL1CacheTagBits(bitsForData);
		
		l1_Cache_Writes++;
		for(DataBlock cb: li)
		{
			if(cb.tagBits.equals(tagBits)) {
				write_hit_at_L1_Cache(tagBits, li, cb);
				cb.setDirtyBit(true);
				
				
				compute_PLRU(cache.pseudo_LRU_L1[getL1Index(bitsForData)], li.indexOf(cb));
				
				return;
			}
		}
		currentRowIndex = getL1Index(bitsForData);
		
		l1_Cache_Write_Misses++;
		
		
		if(li.size()<cache.l1_Sets)
		{
			
			
			for(DataBlock cb: li)
			{
				cb.set_LRU_Counter(cb.get_LRU_Counter()-1);
				cb.set_OPT_Counter(cb.get_OPT_Counter()+1);
			}
				
			
			if(blankCounter != 0)
			{
				li.add(blankIndexHolder.get(0),new DataBlock(originalHexData, tagBits, cache.l1_Sets -1 , true));
				compute_PLRU(cache.pseudo_LRU_L1[getL1Index(bitsForData)], blankIndexHolder.remove(0));
				blankCounter--;
			}
			else
			{
				li.add(new DataBlock(originalHexData, tagBits, cache.l1_Sets -1 , true));
				compute_PLRU(cache.pseudo_LRU_L1[getL1Index(bitsForData)], li.size()-1);
			}
				
			
			if(cache.l2_Cache.size() != 0)
			{
				compute_read_in_L2_Cache(originalHexData, bitsForData, false, null);
			}
			
		}
		else 
		{
			evictDataFrom_L1_Cache(originalHexData, tagBits, li, false);
		}
		
		
	}
	
	
	private void write_hit_at_L1_Cache(String tag, List<DataBlock> li, DataBlock c) {
		
		int value = c.get_LRU_Counter();
		
		for(DataBlock cb: li)
		{
			if(cb.tagBits.equals(tag)) {
				
				cb.set_LRU_Counter(cache.l1_Sets-1);
			}
			else if(cb.get_LRU_Counter() > value)
			{
				cb.set_LRU_Counter(cb.get_LRU_Counter()-1);
			}
		}
		
	}

	
	

	
	
	private void compute_write_in_L2_Cache(String originalHexData, String bitsFromData) {
		
		List<DataBlock> li = cache.l2_Cache.get(getL2Index(bitsFromData));
		String tag = getL2CacheTagBits(bitsFromData);
		
		l2_Cache_Writes++;
		
		for(DataBlock cb: li)
		{
			if(cb.getTagBits().equals(tag)) {
				write_hit_at_L2_Cache(tag, li, cb);
				cb.setDirtyBit(true);
				
				
				compute_PLRU(cache.pseudo_LRU_L2[getL2Index(bitsFromData)], li.indexOf(cb));
				
				return;
			}
		}
		
		l2_Cache_Write_Misses++;
		currentRowIndex = getL1Index(bitsFromData);
		
		
		if(li.size()<cache.l2_Sets)
		{
			for(DataBlock cb: li)
			{
				cb.set_LRU_Counter(cb.get_LRU_Counter()-1);
				cb.set_OPT_Counter(cb.get_OPT_Counter()+1);
			}
				
				
			li.add(new DataBlock(originalHexData, tag, cache.l2_Sets -1 , true));
			
			
			compute_PLRU(cache.pseudo_LRU_L2[getL2Index(bitsFromData)], li.size()-1);
		}
		else 
		{
			evictDataFrom_L2_cache(originalHexData, tag, li, false);
		}
		
	}

	


	
	private void write_hit_at_L2_Cache(String tag, List<DataBlock> li, DataBlock c) {
		
		int value = c.get_LRU_Counter();
		
		for(DataBlock cb: li)
		{
			if(cb.tagBits.equals(tag)) {
				
				cb.set_LRU_Counter(cache.l2_Sets-1);
			}
			else if(cb.get_LRU_Counter() > value)
			{
				cb.set_LRU_Counter(cb.get_LRU_Counter()-1);
			}
		}
		
	}



	
	
	private int getIndexUsingPLRU_Policy(int[] ar) {
		
		int mid = (ar.length-1)/2;
		int levelValue = (mid+1)/2;
		
		return deallocate_PLRU_Array(mid,levelValue,ar);
	}

	
	private int deallocate_PLRU_Array(int middleElement, int lvl, int[] ar) {
		
		if(lvl == 0)
		{
			if(ar[middleElement] == 0)
			{
				ar[middleElement] = 1;
				return middleElement+1;
			}
			else
			{
				ar[middleElement] = 0;
				return middleElement;
			}
		}
		else if(ar[middleElement] == 0)
		{
			ar[middleElement] = 1;
			return deallocate_PLRU_Array(middleElement + lvl, lvl/2, ar);
		}
		else
		{
			ar[middleElement] = 0;
			return deallocate_PLRU_Array(middleElement - lvl, lvl/2, ar);
		}
		
	}
	
	
	void allocate_PLRU_Array(int ar[], int middleElement, int idx, int lvl, int directionalBit)
    {
        if(lvl == 0)
        {
            ar[idx] = directionalBit;
            return;
        }
        else if(middleElement>idx)
        {
            ar[middleElement] = 0;
            allocate_PLRU_Array(ar, middleElement - lvl, idx, lvl/2, directionalBit);
            
        }
        else
        {
            ar[middleElement] = 1;
            allocate_PLRU_Array(ar, middleElement + lvl, idx, lvl/2, directionalBit);
        }
    }
	
	void compute_PLRU(int ar[], int index) {
		
		 int idx = index;
         int dir = 0;
         if(index%2 != 0)
         {
             idx --;
             dir = 1;
         }
         int mid = (ar.length-1)/2;
         allocate_PLRU_Array(ar, mid, idx, (mid+1)/2, dir);
         
	}
	

private int getIndexUsingOPT_Policy(List<DataBlock> li) {
			
		
		int index = 0;
		
		int ar[] = new int[li.size()];
		
		Arrays.fill(ar, Integer.MAX_VALUE);
		
		List<BlockforOptimalPolicy> nodeList = hexDataToIndexMap.get(currentRowIndex);
		
		
		for(int i=0; i<ar.length; i++)
		{
			DataBlock cb = li.get(i);
			
			for(int j=0; j<nodeList.size(); j++)
			{
				BlockforOptimalPolicy node = nodeList.get(j);
				
				if(node.getIndex()>globalOPTIndex)
				{
					String tag = getL1CacheTagBits(hexToBitTable.get(node.getStr()));
					
					if(cb.getTagBits().equals(tag) ) {
						ar[i] = node.getIndex() - globalOPTIndex;
						break;
					}
				}
			}
		}
		

		
		int max = -1;
		for(int i : ar)
			max = Math.max(i, max);
		
		
		
		for(int i=0; i<li.size(); i++)
		{
			if(ar[i] == max )
			{
				return i;
			}
		}
		
		return index;
		
		
	}

	
	private void evictDataFrom_L1_Cache(String originalHexData,String tagBits, List<DataBlock> list, boolean isReadOperation) {
		// TODO Auto-generated method stub
		
		int index = 0;
		
		
		switch(cache.replacementPolicy)
		{
			case 1:{
				index = getIndexUsingPLRU_Policy(cache.pseudo_LRU_L1[getL1Index(hexToBitTable.get(originalHexData))]);
				break;
			}
			case 2:{
				
				index = getIndexUsingOPT_Policy(list);
				int val = list.get(index).get_OPT_Counter();
				for(DataBlock cb: list)
				{
					if(cb.get_OPT_Counter()<val)
						cb.set_OPT_Counter(cb.get_OPT_Counter()+1);
				
				}
				
				break;
			}
			default:{

				for(int i=0; i<list.size(); i++)
				{
					DataBlock cb = list.get(i);
					if(cb.get_LRU_Counter() == 0)
					{
						index = i;
					}
					else
					{
						cb.set_LRU_Counter(cb.get_LRU_Counter()-1);
					}
				}
				
				break;
			}
		}
		
		DataBlock evicted_block = list.remove(index);
		
		if(evicted_block.isDirtyBit())
		{
			l1_Cache_Writebacks++;
		}
		
		
		
		list.add(index, new DataBlock(originalHexData, tagBits, cache.l1_Sets -1 , true));
		
		if(isReadOperation)
		{
			list.get(index).setDirtyBit(false);
		}
		
	
		 
		if(cache.l2_Cache.size() != 0 )
		{
			if(evicted_block.isDirtyBit())
				compute_write_in_L2_Cache(evicted_block.getHexData(), hexToBitTable.get(evicted_block.getHexData()));
			
			compute_read_in_L2_Cache(originalHexData, hexToBitTable.get(originalHexData), false, null);
		}
			
		
		
	}
	
	
	
	

	

	private void evictDataFrom_L2_cache(String originalHexData, String tagBits, List<DataBlock> list, boolean isOperationRead) {
		
		int index = 0;
		
		
		switch (cache.replacementPolicy) {
			case 1:{
				
				index = getIndexUsingPLRU_Policy(cache.pseudo_LRU_L2[getL2Index(hexToBitTable.get(originalHexData))]);
				break;
			}
			case 2:{
				index = getIndexUsingOPT_Policy(list);
				int val = list.get(index).get_OPT_Counter();
				for(DataBlock cb: list)
				{
					if(cb.get_OPT_Counter()<val)
						cb.set_OPT_Counter(cb.get_OPT_Counter()+1);
				
				}
				
				break;
				
			}
			default:{
				for(int i=0; i<list.size(); i++)
				{
					DataBlock cb = list.get(i);
					if(cb.get_LRU_Counter() == 0)
					{
						index = i;
						
					}
					else
					{
						cb.set_LRU_Counter(cb.get_LRU_Counter()-1);
					}
				}
				break;
			}
		}
		
		
		
		DataBlock evicted = list.remove(index);
		
		if(evicted.isDirtyBit())
		{
			l2_Cache_Writebacks++;
		}
		
		list.add(index, new DataBlock(originalHexData, tagBits, cache.l2_Sets -1 , true));
		
		if(isOperationRead)
		{
			list.get(index).setDirtyBit(false);

		}
		
		if(cache.inclusionProperty == 1)
		{
			evictFromL1(evicted);
		}
		
	}
	
	
	
	
	private void evictFromL1(DataBlock evicted) {
			
		int index = getL1Index(hexToBitTable.get(evicted.getHexData()));
		String tag =getL1CacheTagBits(hexToBitTable.get(evicted.getHexData()));
		
		List<DataBlock> li = cache.l1_Cache.get(index);
		
		for(DataBlock cb: li)
		{
			if(cb.getTagBits().equals(tag))
			{
				int idx = li.indexOf(cb);
				blankCounter++;
				blankIndexHolder.add(idx);
				DataBlock temp = li.remove(idx);
				if(temp.isDirtyBit())
					inclusionEvictionCount++;
				break;
			}
		}
		
		
	}


	
	
	
	
	
	
	

}
