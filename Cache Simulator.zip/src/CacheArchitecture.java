import java.util.*;


public class CacheArchitecture {
	
	List<List<DataBlock>> l1_Cache;
	List<List<DataBlock>> l2_Cache;
	
	int l1_TagBits, l1_IndexBits, offsetBits, l1_Sets, l2_TagBits, l2_IndexBits, l2_Sets, replacementPolicy,inclusionProperty, blockSize, L1_Size, L1_Assoc, L2_Size, L2_Assoc;
	String traceFileData;
	int pseudo_LRU_L1 [][];
	int pseudo_LRU_L2 [][];

	
	

	CacheArchitecture(int l1Index, int l1Set, int l2Index, int l2Set, int blockSize, int replacementPolicy, int inclusionProperty, int L1_Size, int L2_Size, int L1_Assoc, int L2_Assoc, String traceFile)
	{
		
		this.l1_Sets = l1Set;
		this.l2_Sets = l2Set;
		this.inclusionProperty = inclusionProperty;
		this.replacementPolicy = replacementPolicy;
		this.blockSize = blockSize;
		
		l1_Cache = new ArrayList<>();
		l2_Cache = new ArrayList<>();
		
		List<DataBlock> temp;
		
		
		
		for(int i = 0; i<l2Index; i++)
		{
			temp = new ArrayList<>();
			l2_Cache.add(temp);
		}
		
		
		for(int i = 0; i<l1Index; i++)
		{
			temp = new ArrayList<>();
			l1_Cache.add(temp);
		}
		
		
		offsetBits = logBase2Function(blockSize);
		
		this.l1_IndexBits = logBase2Function(l1Index);
		this.l2_IndexBits = logBase2Function(l2Index);
		
		l1_TagBits = 32 - (this.l1_IndexBits + offsetBits);
		l2_TagBits = 32 - (this.l2_IndexBits + offsetBits);
		this.L2_Assoc = L2_Assoc;
		this.traceFileData = traceFile;
		this.L1_Size = L1_Size;
		this.L2_Size = L2_Size;
		this.L1_Assoc = L1_Assoc;
		
		initiate_Pseudo_LRU();
		
	}

	private void initiate_Pseudo_LRU() {
		int tempL1Set = l1_Sets;
		int tempL2Set = l2_Sets;
		if(l1_Sets < 2)
		{
			tempL1Set = 2;
		}
		if(l2_Sets <2)
		{
			tempL2Set = 2;
		}
		pseudo_LRU_L1 =new int [l1_Cache.size()][tempL1Set-1];
		pseudo_LRU_L2 =new int [l2_Cache.size()][tempL2Set-1];
		
		
	}
	
	int logBase2Function(int x) {
	    return (int) (Math.log(x) / Math.log(2));
	}
	 
	


	

}
