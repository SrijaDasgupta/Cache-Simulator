
public class sim_cache {
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		new BackBone(
				Integer.parseInt(args[0]),
				Integer.parseInt(args[1]),
				Integer.parseInt(args[2]),
				Integer.parseInt(args[3]),
				Integer.parseInt(args[4]),
				Integer.parseInt(args[5]),
				Integer.parseInt(args[6]),
				args[7]
				);

	}

}
