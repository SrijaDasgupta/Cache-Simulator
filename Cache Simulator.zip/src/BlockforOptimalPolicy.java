
public class BlockforOptimalPolicy {
	
	String str;
	int index;
	public BlockforOptimalPolicy(String str, int index) {
		super();
		this.str = str;
		this.index = index;
	}
	public String getStr() {
		return str;
	}
	public void setStr(String str) {
		this.str = str;
	}
	public int getIndex() {
		return index;
	}
	public void setIndex(int index) {
		this.index = index;
	}

}
