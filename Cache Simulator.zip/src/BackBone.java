import java.io.*;
import java.util.*; 


public class BackBone {
	
	
	  Map<Character,String> map = new HashMap<>() {{
		put('0',"0000");
		put('1',"0001");
		put('2',"0010");
		put('3',"0011");
		put('4',"0100");
		put('5',"0101");
		put('6',"0110");
		put('7',"0111");
		put('8',"1000");
		put('9',"1001");
		put('A',"1010");
		put('B',"1011");
		put('C',"1100");
		put('D',"1101");
		put('E',"1110");
		put('F',"1111");
	}};
	
	
	
	
	 String hexToBin(String str)
	{	
		str= str.toUpperCase();
		String ans = "";
		for(char c:str.toCharArray())
		{
			ans += map.get(c);
		}
		
		return ans;
	}

	
	int block_size,l1CacheSize,l1CacheAssociativity,l2CacheSize,l2CacheAssociativity;
	int cacheReplacementPolicy,cacheInclusionProperty,l1CacheRows,l2CacheRows;
	String traceFile;
	
	private List<String> sourceData;
	private Map<String,String> dataToBitsTable;
	
	private CacheArchitecture cache;
	
	
	public BackBone(int blockSize, int l1Size, int l1Assoc, int l2Size, int l2Assoc, int replacementPolicy,
			int inclusionProperty, String traceFile) {
		
		
		this.cacheReplacementPolicy = replacementPolicy;
		this.cacheInclusionProperty = inclusionProperty;
		this.traceFile = traceFile;
		this.block_size = blockSize;
		this.l1CacheSize = l1Size;
		this.l1CacheAssociativity = l1Assoc;
		this.l2CacheSize = l2Size;
		this.l2CacheAssociativity = l2Assoc;
		
		
		
		computeCacheRows();
		cache = new CacheArchitecture(l1CacheRows, l1Assoc, l2CacheRows, l2Assoc, blockSize, replacementPolicy, inclusionProperty, l1Size, l2Size, l1Assoc, l2Assoc, traceFile);
		
		sourceData = new ArrayList<>();
		dataToBitsTable = new HashMap<>();
		
		
		readFromTraceFile();
		
		new ExecutionClass(cache, dataToBitsTable, sourceData);
		
	}
	
	
	private void computeCacheRows() {
		// TODO Auto-generated method stub
		
		l1CacheAssociativity = l1CacheAssociativity == 0? 1 : l1CacheAssociativity;
		l2CacheAssociativity = l2CacheAssociativity == 0? 1 : l2CacheAssociativity;
		
		l1CacheRows = l1CacheSize / (l1CacheAssociativity * block_size);
		l2CacheRows = l2CacheSize / (l2CacheAssociativity * block_size);
		
		
	}

	
	private void readFromTraceFile() {
		
		try {
			File file= new File(traceFile);
			
			BufferedReader br = new BufferedReader(new FileReader(file));
			//br.read();
			String str;
			while((str = br.readLine()) != null)
			{
				
				if(str.length() == 0)
					continue;
				sourceData.add(str);
				modifyHexData(str);
			}
			
			br.close();
			
		}
		catch(Exception e)
		{
		}
		

	}

	private void modifyHexData(String str) {
		str = str.trim();
		String ptr = "";
		try {
			ptr = str = str.split(" ")[1];
			if(dataToBitsTable.containsKey(ptr))
				return;
		}catch(Exception ignored){
			return;
		}
		
		String zero = "00000000";
		if(ptr.length() != 8)
		{
			ptr = zero.substring(0 , 8 - str.length()) + ptr;
			
		}
		dataToBitsTable.put(str, hexToBin(ptr));
		
	}
	
	

	
}
