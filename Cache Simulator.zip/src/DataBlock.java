
public class DataBlock {
	String originalHexdata, tagBits;
	int LRU_Counter, OPT_Counter;
	boolean dBit;
	
	public DataBlock(String data, String tag, int lRUaccessCounter, boolean isDirtyBit) {
		super();
		
		LRU_Counter = lRUaccessCounter;
		this.dBit = isDirtyBit;
		this.originalHexdata = data;
		this.tagBits = tag;
		OPT_Counter = 0;
	}
	
	public int get_LRU_Counter() {
		return LRU_Counter;
	}
	public void set_LRU_Counter(int lRUaccessCounter) {
		LRU_Counter = lRUaccessCounter;
	}
	public boolean isDirtyBit() {
		return dBit;
	}
	public void setDirtyBit(boolean isDirtyBit) {
		this.dBit = isDirtyBit;
	}
	
	public int get_OPT_Counter() {
		return OPT_Counter;
	}
	public void set_OPT_Counter(int oPTaccessCounter) {
		OPT_Counter = oPTaccessCounter;
	}
	
	
	public String getHexData() {
		return originalHexdata;
	}
	public void setHexData(String data) {
		this.originalHexdata = data;
	}
	public String getTagBits() {
		return tagBits;
	}
	public void setTagBits(String tag) {
		this.tagBits = tag;
	}
	
	
	
	
	
	
}
